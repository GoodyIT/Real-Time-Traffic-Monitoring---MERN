# Singarpore - Malaysia Traffic real time monitor app

- Spec:
   #### NodeJs 
   #### ExpressJS
   #### MongoDB
   #### React / Redux / Reduc-Thunk
   #### Material UI
   #### Google MAP API
   #### Foreign Exchange Rate API
   #### Weather API
   #### Google Adsense
   #### Real Time Traffic Phone
   #### Cron job 
   #### MySQL Support
  
## How to run  
   #### npm install
   #### npm start

## License
MERN is released under the [MIT License](http://www.opensource.org/licenses/MIT).
