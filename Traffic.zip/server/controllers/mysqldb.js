import mysql from 'mysql';

const connection = mysql.createConnection({
  host: 'localhost',
    user: 'root',
    password: 'loveonsand09',
    database: 'traffic',
    multipleStatements: true,
});

connection.connect();

export default connection;
